

DELETE FROM names
WHERE id = 3;

select * from names;